<!DOCTYPE html>
<html>

  <head>
  
  @include('head')
 
  </head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
 @include('header')
 
    @include('sidebar')
    <div class="content-wrapper">
      <section class="content-header">
      <h1>Dashboard</h1>
      <ol class="breadcrumb">
        <li><a href="{{url('dashboard/')}}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li><p bgcolor="blue">
      </ol>
    </section>
    <section class="content">
      <div class="row">
       {{--  @if(Auth::check())
          @role('school admin') --}}
          <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-maroon">
              <div class="inner">
                <h3>0</h3>
                <p>School Events</p>
              </div>
              <div class="icon">
                <i class="ion ion-calendar"></i>
              </div>
              <a href="" class="small-box-footer">Manage Events <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      
         <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-green">
              <div class="inner">
                <h3>0</h3>
                <p>Student Available</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="" class="small-box-footer">Add Student <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
         
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-purple">
              <div class="inner">
                <h3>0</h3>
                <p>Teacher Available</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="" class="small-box-footer">Add Teacher <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

       {{--  @if(Auth::check())
          @role('admin') --}}
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-teal">
              <div class="inner">
                <h3>0</h3>
                <p>Exam</p>
              </div>
              <div class="icon">
                <i class="ion ion-briefcase"></i>
              </div>
              <a href="" class="small-box-footer">Manage Exam <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
       {{--    @endrole
        @endif --}}
      

      {{-- month wise orders and total bill inserted here --}}
     <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-yellow">
              <div class="inner">
                <h3>0</h3>
                <p>Upcomming Holidays</p>
              </div>
              <div class="icon">
                <i class="fa fa-newspaper-o"></i>
              </div>
              <a href="" class="small-box-footer">View Holidays <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-red">
              <div class="inner">
                <h3>0</h3>
                <p>Todays Event</p>
              </div>
              <div class="icon">
                <i class="fa fa-calendar"></i>
              </div>
              <a href="" class="small-box-footer">View Todays Event <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
       {{--  @endrole
          @endif

       @if(Auth::check())
        @role('admin')    --}}
          <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-red">
              <div class="inner">
                <h3>{{-- {{ count($UserCount) }} --}}</h3>
                <p>User Registration</p>
              </div>
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>
              <a href="{{ route('users.index') }}" class="small-box-footer">View users <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
       {{--  @endrole
          @endif --}}

    </section>
    </div>
    <!-- /.content -->
  </div>
  

  
</div>
<!-- ./wrapper -->

 @include('includes.admin.js')
</body>
</html>
