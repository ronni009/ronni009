@extends('admin_template')

@section('content')
           {{-- message --}}

@if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
        </div>
    @endif
@if ($message = Session::get('exists'))
    <div class="alert alert-danger">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
 <section class="content-header">
          <h1>
            Time Table
            <small>Edit Time Table</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Time Table</a></li>
            <li class="active">Edit Time Table</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
              <div class="col-md-12">
                <a href="{{ route('time.index') }}" class="btn btn-primary pull-right">List</a>
                </div>
                <div class="col-md-12">
                <div class="col-md-3"></div>
                    <div class="col-md-6">
                    <div class="box">
                        <div class="box-header">
                           
                        </div>
                        <div class="box-body">
                        
                          {!! Form::open(['route'=>['time.update',$timeEdit->id],'method'=>'PATCH']) !!}
                          {!! method_field('PATCH') !!}
                              <div class="box-body">
                             
                                <div class="form-group">
                                    <div class="row">
                                    <div class="col-md-6">
                                        <label for="user_fullname">From <span style = "color:red">*</span></label>
                                        <input type="text" class="form-control" name="from" placeholder="Ex. 7.00,8.00,9.00 etc" value="{{ $timeEdit->from }}" />

                                        <label for="user_fullname">To <span style = "color:red">*</span></label>
                                        <input type="text" class="form-control" name="to" placeholder="Ex. 7.00,8.00,9.00 etc" value="{{ $timeEdit->to }}" />
                                    </div>
                                   
                                   
                                    </div>
                                </div>
                               
                              </div><!-- /.box-body -->
            
                              <div class="box-footer">
                                <button type="submit" class="btn btn-primary">Update</button>
                              </div>
                            </form>
                        </div>
                    </div>
                    </div>
                    <div class="col-md-3"></div>
                </div>
               
                
            </div>
        </section><!-- /.content -->


   
@stop