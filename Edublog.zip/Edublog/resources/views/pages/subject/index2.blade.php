 @extends('admin_template')

@section('content')
        {{-- messages --}}
    @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
        </div>
    @endif
  @if ($message = Session::get('success'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  @if ($message = Session::get('updated'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
   @if ($message = Session::get('deleted'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  {{-- box begins --}}
   <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Subject to Standard
            <small>Manage Subject to Standard</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Subject</a></li>
            <li class="active">Manage Subject</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
               
                <div class="col-md-12">
                
              
                    <div class="col-md-12">
                    <div class="box">
                <div class="box-header">
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Standard Name</th>
                        <th>Sub1</th>
                        <th>Sub2</th>
                        <th>Sub3</th>
                        <th>Sub4</th>
                        <th>Sub5</th>
                        <th>Sub6</th>
                        <th>Sub7</th>
                        <th>Sub8</th>
                        <th>Sub9</th>
                        <th>Sub10</th>
                        <th>Sub11</th>
                        <th>Sub12</th>
                        <th>Sub13</th>
                        <th>Sub14</th>
                        <th>Sub15</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                @forelse($stdDetail as $stdDetails)
                    <tr>
                        
                        <td>{{ $stdDetails->id }}</td>
                        <td>{{ $stdDetails->standard_name }}</td>
                        <td>{{ $stdDetails->sub1 }}</td>
                        <td>{{ $stdDetails->sub2 }}</td>
                        <td>{{ $stdDetails->sub3 }}</td>
                        <td>{{ $stdDetails->sub4 }}</td>
                        <td>{{ $stdDetails->sub5 }}</td>
                        <td>{{ $stdDetails->sub6 }}</td>
                        <td>{{ $stdDetails->sub7 }}</td>
                        <td>{{ $stdDetails->sub8 }}</td>
                        <td>{{ $stdDetails->sub9 }}</td>
                        <td>{{ $stdDetails->sub10 }}</td>
                        <td>{{ $stdDetails->sub11 }}</td>
                        <td>{{ $stdDetails->sub12 }}</td>
                        <td>{{ $stdDetails->sub13 }}</td>
                        <td>{{ $stdDetails->sub14 }}</td>
                        <td>{{ $stdDetails->sub15 }}</td>
                        <td>
                            <a href="{{ route('subtostd.edit',$stdDetails->id) }}" class="btn btn-success"><i class="fa fa-edit"></i></a>
                           {{--  <a href="" onclick="return confirm('are you sure to delete?')" class="btn btn-danger"><i class="fa fa-remove"></i></a> --}}
                        </td>
                    </tr>
                    @empty
                    <tr class="odd gradeX">
                    <td colspan=3 class="text-center">No Records Found</td>
                    </tr>  
                  @endforelse
                    </tbody>
                </table>
            </div>
        </div>
                    </div>
                </div>
               
                
            </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

   
@stop