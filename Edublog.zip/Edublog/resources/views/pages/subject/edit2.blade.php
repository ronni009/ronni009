@extends('admin_template')
@section('content')
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
          </div>
        @endif

        @if ($message = Session::get('success'))
          <div class="alert alert-success">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <p>{{ $message }}</p>
          </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Subject to Standard</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>


       {!! Form::open(['route'=>['subtostd.update',$subEdit->id],'method'=>'PATCH']) !!}
                          {!! method_field('PATCH') !!}
    <div class="box-body">
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
               {{--  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> --}}
              {!! Form::label('standard_name','Select standard') !!}
              {!! Form::select('standard_name',@$standardDetail,@$subEdit->standard_name,['class'=>'form-control','id'=>'standard_name','placeholder'=>'Select here..','required'=>'required']) !!}
            </div>

              <!-- /.form-group -->
               
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>

              <!-- /.form-group -->
            </div>

            <div class = "col-md-3">
              <div class = "form-group">
                  {!! Form::label('subject_id','Select Subject') !!}
          {!! Form::select('sub1',@$subjectDetail,@$subEdit->sub1,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub2',@$subjectDetail,@$subEdit->sub2,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub3',@$subjectDetail,@$subEdit->sub3,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub4',@$subjectDetail,@$subEdit->sub4,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub5',@$subjectDetail,@$subEdit->sub5,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          <button id = "add1" class = "btn btn-primary">Add More</button>

              </div>

            </div>


            <div id = "show1" class = "col-md-3">
              <div class = "form-group">
                  {!! Form::label('subject_id','Select Subject') !!}
          {!! Form::select('sub6',@$subjectDetail,@$subEdit->sub6,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub7',@$subjectDetail,@$subEdit->sub7,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub8',@$subjectDetail,@$subEdit->sub8,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub9',@$subjectDetail,@$subEdit->sub9,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub10',@$subjectDetail,@$subEdit->sub10,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>


          <button id = "add2" class = "btn btn-primary">Add More</button>
              </div>

            </div>

            <div id = "show2" class = "col-md-3">
              <div class = "form-group">
                  {!! Form::label('subject_id','Select Subject') !!}
          {!! Form::select('sub11',@$subjectDetail,@$subEdit->sub11,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub12',@$subjectDetail,@$subEdit->sub12,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub13',@$subjectDetail,@$subEdit->sub13,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub14',@$subjectDetail,@$subEdit->sub14,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {!! Form::select('sub15',@$subjectDetail,@$subEdit->sub15,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']) !!}<br>

          {{-- <button class = "btn btn-primary">Add More</button> --}}
              </div>

            </div>

        </div>
    </div>
</div>



</section>

<script>
$(document).ready(
    function(){
            $("#show1").hide();
    });
</script>

<script>
$(document).ready(
    function(){
            $("#show2").hide();
    });
</script>

<script>
$(document).ready(
    function(){
        $("#add1").click(function () {
            $("#show1").show("slow");
        });

    });
</script>

<script>
$(document).ready(
    function(){
        $("#add2").click(function () {
            $("#show2").show("slow");
        });

    });
</script>

  {!! Form::close() !!}
@endsection