@extends('admin_template')
@section('content')
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
          </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New School</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

	{!! Form::open(['route'=>'school.store','method'=>'POST' , 'enctype'=>'multipart/form-data']) !!}
       {!! csrf_field() !!}
    <div class="box-body">
          <div class="row">

            <div class="col-md-6">
              <div class="form-group">
               {{--  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> --}}
              {!! Form::label('school_name','School Name') !!}<span style = "color:red">*</span>
              {!! Form::text('school_name',null,['class'=>'form-control','id'=>'school_name','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>

            <div class = "form-group">
              {!! Form::label('school_address','School Address') !!}<span style = "color:red">*</span>
             {!! Form::text('school_address',null,['class'=>'form-control','id'=>'school_address','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>

            <div class="form-group">
               {{--  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> --}}
              {!! Form::label('school_state','State Name') !!}<span style = "color:red">*</span>
              {!! Form::text('school_state',null,['class'=>'form-control','id'=>'school_state','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>

            <div class="form-group">
               
              {!! Form::label('school_phone1','School Phone1') !!}<span style = "color:red">*</span>
              {!! Form::text('school_phone1',null,['class'=>'form-control','id'=>'school_phone1','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>

            <div class="form-group">
               
              {!! Form::label('school_email','School Email') !!}<span style = "color:red">*</span>
              {!! Form::text('school_email',null,['class'=>'form-control','id'=>'school_email','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>

            <div class="form-group">
               
              {!! Form::label('school_logo','School Logo') !!}<span style = "color:red">*</span>
              {!! Form::file('school_logo',null,['class'=>'form-control','id'=>'school_logo','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>

              <!-- /.form-group -->
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
              
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Add School</button>
               </div>

               </div>  <!-- /.col-md-6 -->

            <div class="col-md-6">
              <div class="form-group">
              {!! Form::label('school_person_name','School Person Name') !!}<span style = "color:red">*</span>
              {!! Form::text('school_person_name',null,['class'=>'form-control','id'=>'school_person_name','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>

            <div class="form-group">
              {!! Form::label('school_city','City Name') !!}<span style = "color:red">*</span>
              {!! Form::text('school_city',null,['class'=>'form-control','id'=>'school_city','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>

            <div class="form-group">
              {!! Form::label('school_postal_code','Pin Code') !!}<span style = "color:red">*</span>
              {!! Form::text('school_postal_code',null,['class'=>'form-control','id'=>'school_postal_code','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>

            <div class="form-group">
              {!! Form::label('school_phone2','School Phone2') !!}<span style = "color:red">*</span>
              {!! Form::text('school_phone2',null,['class'=>'form-control','id'=>'school_phone2','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>
              
              </div>


               

              <!-- /.form-group -->
           
        </div> <!-- /.row -->
    </div>
</div>
</section>

	{!! Form::close() !!}
@endsection