 @extends('admin_template')

@section('content')
        {{-- messages --}}
	@if ($message = Session::get('success'))
		<div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<p>{{ $message }}</p>
		</div>
	@endif
  @if ($message = Session::get('updated'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
   @if ($message = Session::get('deleted'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  {{-- box begins --}}
	 <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of School</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
                {{-- <a  href="{{ route('school.create') }}" button type = "button" class = "btn btn-primary" >Add School</button></a> --}}
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
			<th>Id</th>
			
      <th>School Name</th>
      <th>School Address</th>
      <th>School State</th>
      <th>School City</th>
      <th>School Postal Code</th>
      <th>School Phone1</th>
      <th>School Phone2</th>
      <th>School Email</th>
      <th>School Logo</th>
      <th>School Person Name</th>
      <th>Action</th>
		</tr>   
                </thead>
                <tbody>
                  @forelse($schoolDetail as $schoolDetails)
                  <tr class="odd gradeX">
                        <td>{{ $schoolDetails->id }}</td> 
                        <td>{{ $schoolDetails->school_name }}</td>
                        <td>{{ $schoolDetails->school_address }}</td>
                        <td>{{ $schoolDetails->school_state }}</td>
                        <td>{{ $schoolDetails->school_city }}</td>
                        <td>{{ $schoolDetails->school_postal_code }}</td>
                        <td>{{ $schoolDetails->school_phone1 }}</td>
                        <td>{{ $schoolDetails->school_phone2 }}</td>
                        <td>{{ $schoolDetails->school_email }}</td>
                        <td>{{ $schoolDetails->school_logo }}</td>
                        <td>{{ $schoolDetails->school_person_name  }}</td>
                  <td>
                     <a class="btn btn-primary" href="{{ route('school.edit',$schoolDetails->id)}}">Edit</a>
                  </td>
                    </tr>
                  @empty
                  <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>  
                  @endforelse
                    
                </tbody>
                <tfoot>
                 <tr>
			<th>Id</th>
      <th>School Name</th>
      <th>School Address</th>
      <th>School State</th>
      <th>School City</th>
      <th>School Postal Code</th>
      <th>School Phone1</th>
      <th>School Phone2</th>
      <th>School Email</th>
      <th>School Logo</th>
      <th>School Person Name</th>
      <th>Action</th>
		</tr>
                </tfoot>
              </table>
           {{--   {!! $data->links() !!}  --}}  
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

   
@stop