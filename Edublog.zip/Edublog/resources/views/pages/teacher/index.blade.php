 @extends('admin_template')

@section('content')
        {{-- messages --}}
    @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
        </div>
    @endif
  @if ($message = Session::get('success'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  @if ($message = Session::get('updated'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
   @if ($message = Session::get('deleted'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  {{-- box begins --}}
   <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Teacher
            <small>Manage Teacher</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Teacher</a></li>
            <li class="active">Manage Teacher</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">

               <div class="col-md-12">

                <a href="{{route('teacher.create')}}" class="btn btn-primary pull-right">Add Teacher</a>

                </div>
               
                <div class="col-md-12">
                
                
                    <div class="col-md-12">
                    <div class="box">
                <div class="box-header">
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Teacher Name</th>
                        <th>Teacher Email</th>
                        <th>Teacher Phone</th>
                        <th>Teacher Birthdate</th>
                         <th>Gender</th>
                         <th>Marital Status</th>
                         <th>Teacher Address</th>
                        <th>Teacher Education</th>
                        <th>Teacher Experience</th>
                        <th>Teacher Notes</th>
                        <th>Designation</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                @forelse($teacherDetail as $teacherDetails)
                    <tr>
                        
                        <td>{{ $teacherDetails->id }}</td>
                        <td>{{ $teacherDetails->name }}</td>
                        <td>{{ $teacherDetails->email }}</td>
                        <td>{{ $teacherDetails->teacher_phone }}</td>
                        <td>{{ $teacherDetails->teacher_birthdate }}</td>
                        <td>{{ $teacherDetails->gender }}</td>
                        <td>{{ $teacherDetails->marital_status }}</td>
                        <td>{{ $teacherDetails->teacher_address }}</td>
                        <td>{{ $teacherDetails->teacher_education }}</td>
                        <td>{{ $teacherDetails->teacher_exp }}</td>
                        <td>{{ $teacherDetails->teacher_notes }}</td>
                        <td>{{ $teacherDetails->designation }}</td>
                        
                        <td>
                          {{--  <a title="View Details" data-toggle="tooltip"  class="badge bg-blue" href="{{ route('teacher.show',$teacherDetails->id) }}" ><i class="fa fa-eye"></i></a> --}}
                            <a href="{{ route('teacher.edit',$teacherDetails->id) }}" class="btn btn-success"><i class="fa fa-edit"></i></a>
                           

                        </td>
                    </tr>
                    @empty
                    <tr class="odd gradeX">
                    <td colspan=3 class="text-center">No Records Found</td>
                    </tr>  
                  @endforelse
                    </tbody>
                </table>
            </div>
        </div>
                    </div>
                </div>
               
                
            </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

   
@stop