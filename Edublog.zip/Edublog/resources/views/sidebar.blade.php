  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="{{ asset("/bower_components/AdminLTE/dist/img/user2-160x160.jpg") }}" class="img-circle" alt="User Image" />
         {{--  <span style="color:white ">Welcome! {{ ucfirst(Auth::user()->name) }}</span>
            <span style="color:white ">({{Auth::user()->roles->first()->name}})</span> --}}
        </div>
        <div class="pull-left info">
          <p> {{ ucfirst(Auth::user()->name) }}({{ Auth::user()->roles->first()->name }} )</p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
        </div>
      <!-- Sidebar Menu -->
      <ul class="sidebar-menu">
         <li><a href="/dashboard"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
          
          

         {{--  <li><a href=""><i class="fa fa-pencil-square-o"></i><span>Student Enquiry</span></a></li> --}}

        @if(Auth::check())
          @role('admin')
          <li class="treeview">
          <a href="#">
            <i class="fa fa-database"></i>
            <span>User Management</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>User</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
            
           <li><a href="{{ route('users.create') }}"><i class="fa fa-user-plus"></i>Add User</a></li>
             <li><a href="{{ route('users.index') }}"><i class="fa fa-users"></i>Manage User</a></li>
          </ul>
          </li>
          
          </ul>
          <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i>
            <span>Roles</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
                        <li><a href="{{ route('roles.create') }}"><i class="fa fa-user-plus"></i>Add Role</a></li>
             <li><a href="{{ route('roles.index') }}"><i class="fa fa-users"></i>Manage Role</a></li>
          
          </ul>
          </li>
          
          </ul>

          </li>

          <li class="treeview">
          <a href="#">
            <i class="fa fa-graduation-cap"></i>
            <span>Update School Profile</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="{{ route('school.create') }}"><i class="fa fa-plus"></i>Add school</a></li>
             <li><a href="{{ route('school.index') }}"><i class="fa fa-list"></i>List school</a></li>
          </ul>
        </li>
        
          @endrole
           @endif

        @if(Auth::check())   
          @role('school admin')


          <li class="treeview">
          <a href="#">
            <i class="fa fa-graduation-cap"></i>
            <span>Update School Profile</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            @if(Auth::check())
              @role('admin')
            <li><a href=""><i class="fa fa-plus"></i>Add school</a></li>
            @endrole
            @endif
             <li><a href="{{ route('school.index') }}"><i class="fa fa-list"></i>List school</a></li>
          </ul> 
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-database"></i>
            <span>Master</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-tasks"></i>
            <span>Manage Standard</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
            
             <li><a href="{{ route('standard.index') }}"><i class="fa fa-list"></i>List Standard</a></li>
          </ul>
          </li>
          </ul>

          <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-tags"></i>
            <span>Manage Division</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
            
             <li><a href="{{ route('division.index') }}"><i class="fa fa-list"></i>List Division</a></li>
          </ul>
          </li>
          </ul>

          <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Manage Subject</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
            
             <li><a href="{{ route('subject.index') }}"><i class="fa fa-list"></i>Add Subject</a></li>
             <li><a href="{{ route('subtostd.create') }}"><i class="fa fa-list"></i>Add Subject to Std</a></li>
             <li><a href="{{ route('subtostd.index') }}"><i class="fa fa-list"></i>List Subject to Std</a></li>
          </ul>
          </li>
          </ul>

           <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i>
            <span>Manage Time Table</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
            
             <li><a href="{{ route('time.index') }}"><i class="fa fa-list"></i>List Time Table</a></li>
          </ul>
          </li>
          </ul>

          </li>


          <li class="treeview">
          <a href="#">
            <i class="fa fa-graduation-cap"></i>
            <span>Teacher Management</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="{{ route('teacher.create') }}"><i class="fa fa-plus"></i>Add Teacher</a></li>
             <li><a href="{{ route('teacher.index') }}"><i class="fa fa-list"></i>List Teacher</a></li>
             
             <li><a href="{{ route('class.index') }}"><i class="fa fa-list"></i>List Class Teacher</a></li>
          </ul>
        </li>

       {{--  <li class="treeview">
          <a href="#">
            <i class="fa fa-tasks"></i>
            <span>Standard Management</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-plus"></i>Add Standard</a></li>
             <li><a href=""><i class="fa fa-list"></i>List Standard</a></li>
          </ul>
        </li> --}}

        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>Student Management</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-plus"></i>Add Student</a></li>
             <li><a href=""><i class="fa fa-list"></i>List Student</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-calendar-check-o"></i>
            <span>Student Attendence</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-plus"></i>Add Attendence</a></li>
             <li><a href=""><i class="fa fa-list"></i>List Attendence</a></li>
          </ul>
        </li>

         <li class="treeview">
          <a href="#">
            <i class="fa fa-briefcase"></i>
            <span>Exam Management</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-plus"></i>Add Exam</a></li>
             <li><a href=""><i class="fa fa-list"></i>List Exam</a></li>
          </ul>
        </li>

         <li class="treeview">
          <a href="#">
            <i class="fa fa-calendar"></i>
            <span>Event Management</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-plus"></i>Add Event</a></li>
             <li><a href=""><i class="fa fa-list"></i>List Event</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-calendar"></i>
            <span>Holiday Management</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-plus"></i>Add Holiday</a></li>
             <li><a href=""><i class="fa fa-list"></i>List Holiday</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>Top 10 Student</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-plus"></i>Add Student Rank</a></li>
             <li><a href=""><i class="fa fa-list"></i>List Student Rank</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-tasks"></i>
            <span>Noticeboard Management</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-plus"></i>Add Notice</a></li>
             <li><a href=""><i class="fa fa-list"></i>List Notice</a></li>
          </ul>
        </li>
        @endrole
        @endif
          <li><a href=""><i class="fa fa-pencil-square-o"></i><span>Student Enquiry</span></a></li>

         
{{-- 
        @if(Auth::check())
          @role('admin') --}}
        {{--   <li><a href=""><i class="fa fa-pencil-square-o"></i><span>Student Enquiry</span></a></li> --}}
        {{--  <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>User</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="{{ route('users.create') }}"><i class="fa fa-user-plus"></i>Add User</a></li>
             <li><a href="{{ route('users.index') }}"><i class="fa fa-users"></i>Manage User</a></li>
           
          </ul>
        </li> --}}
      {{--   @endrole
      @endif --}}
        
       {{--  @if(Auth::check())
          @role('admin') --}}
        {{--  <li class="treeview">
          <a href="#">
            <i class="fa fa-users "></i>
            <span>Role</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="{{ route('roles.create') }}"><i class="fa fa-user-plus"></i>Add Role</a></li>
             <li><a href="{{ route('roles.index') }}"><i class="fa fa-users"></i>Manage Role</a></li>
           
          </ul>
        </li> --}}
         {{--  @endrole
        @endif --}}
     
       


        

      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
