 @extends('admin_template')

@section('content')

 <section class="content-header">
            <ol class="breadcrumb">
        <li><a href="{{url('')}}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="{{url('')}}"><i class="fa fa-sitemap"></i> Users</a></li>
        <li class="active">Manage Users</li>
      </ol>
  </section>


<!--<div class="row">
	    <div class="col-lg-12 margin-tb">
	        <div class="pull-left">
	            <h2>Users Management</h2>
	        </div>
	        <div class="pull-right">
	            <a class="btn btn-success" href="{{ route('users.create') }}"> Create New User</a>
	        </div>
	    </div>
	</div>-->
	@if ($message = Session::get('success'))
		<div class="alert alert-success">
			<p>{{ $message }}</p>
		</div>
	@endif
	 <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of Users</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
                <a  href="{{ route('users.create') }}" button type = "button" class = "btn btn-primary" >Add User</button></a>
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
			<th>No</th>
			<th>Name</th>
			<th>Email</th>
			<th>Roles</th>
      <th>Status</th>
			<th >Action</th>
		</tr>
                </thead>
                <tbody>
                   @if(!count($data ))
                        
                    <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>    
                        
                @else
               @foreach ($data as $key => $user)
                    <tr class="odd gradeX">
                        <td>{{ ++$i }}</td> 
						<td>{{ $user->name }}</td>
						<td>{{ $user->email }}</td>
						<td>
							@if(!empty($user->roles))
							@foreach($user->roles as $v)
							<label class="label label-success">{{ $v->display_name }}</label>
				@endforeach
				@endif
						</td>
            
              <td>{{ $user->status }}</td>
            
    <td>
			<a class="btn btn-info" href="{{ route('users.show',$user->id) }}">Show</a>
      @permission('role-edit')
			<a class="btn btn-primary" href="{{ route('users.edit',$user->id) }}">Edit</a>
      @endpermission
      
      @permission('role-delete')
			{!! Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger','onclick'=>'return confirm("Are you sure?")']) !!}
        	{!! Form::close() !!}
          @endpermission
		</td>
                @endforeach 

                @endif   


                </tbody>
                <tfoot>
                 <tr>
			<th>No</th>
			<th>Name</th>
			<th>Email</th>
			<th>Roles</th>
      <th>Status</th>
			<th>Action</th>
		</tr>
                </tfoot>
              </table>
             {!! $data->links() !!}   
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

   
@stop
	<!--<table class="table table-bordered">
		<tr>
			<th>No</th>
			<th>Name</th>
			<th>Email</th>
			<th>Roles</th>
			<th width="280px">Action</th>
		</tr>
	@foreach ($data as $key => $user)
	<tr>
		<td>{{ ++$i }}</td>
		<td>{{ $user->name }}</td>
		<td>{{ $user->email }}</td>
		<td>
			@if(!empty($user->roles))
				@foreach($user->roles as $v)
					<label class="label label-success">{{ $v->display_name }}</label>
				@endforeach
			@endif
		</td>
		<td>
			<a class="btn btn-info" href="{{ route('users.show',$user->id) }}">Show</a>
			<a class="btn btn-primary" href="{{ route('users.edit',$user->id) }}">Edit</a>
			{!! Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
        	{!! Form::close() !!}
		</td>
	</tr>
	@endforeach
	</table>
	{!! $data->render() !!}-->
