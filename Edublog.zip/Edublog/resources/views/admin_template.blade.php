<!DOCTYPE html>
<html>

  <head>
  
  @include('head')
 
  </head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
 @include('header')
 
    @include('sidebar')
 
    <div class="content-wrapper">

    <section class="content">

      <!-- Your Page Content Here -->
       @yield('content')

    </section>
    <!-- /.content -->
  </div>
  

  
</div>
<!-- ./wrapper -->

 @include('includes.admin.js')

<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 2.2.0 -->
<!-- <script src="{{ asset ("/bower_components/AdminLTE/plugins/jQuery/jQuery-2.2.0.min.js") }}"></script>
<!-- Bootstrap 3.3.6 -->
<!--<script src="{{ asset ("/bower_components/AdminLTE/bootstrap/js/bootstrap.min.js") }}" type="text/javascript">
  </script>
<!-- AdminLTE App -->
<!-- <script src="{{ asset ("/bower_components/AdminLTE/dist/js/app.min.js") }}" type="text/javascript"></script>

-->
</body>
</html>
