<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class standard_master extends Model
{
	protected $table = "standard_masters";

    protected $fillable = [
    		'standard_name',
            ];
}
