<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subject_master extends Model
{
	protected $table = "subject_masters";

    protected $fillable = [
    	'subject_name',
    ];	
}
