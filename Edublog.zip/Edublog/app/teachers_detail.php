<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class teachers_detail extends Model
{
    protected $table = "teachers_details";

    protected $fillable =[
            'user_id',
            'name',
            'email',
    		'teacher_birthdate',
    		'unique_id',
    		'gender',
    		'marital_status',
    		'teacher_address',
    		'teacher_phone',
    		'roles',
    		'teacher_exp',
    		'teacher_education',
    		'teacher_notes',
    		'editor1',
    		'designation',
    		'teacher_photo',
            'resume',
    ];
}
