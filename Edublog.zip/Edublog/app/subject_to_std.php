<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subject_to_std extends Model
{
    protected $table ="subject_to_stds";

    protected $fillable  = [
    		'standard_name',
    		'sub1',
    		'sub2',
    		'sub3',
    		'sub4',
    		'sub5',
    		'sub6',
    		'sub7',
    		'sub8',
    		'sub9',
    		'sub10',
    		'sub11',
    		'sub12',
    		'sub13',
    		'sub14',
    		'sub15',
    ];
}
