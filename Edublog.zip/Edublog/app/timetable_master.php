<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class timetable_master extends Model
{
    protected $table = "timetable_masters";

    protected $fillable = [
    		'from',
    		'to',
    ];
}
