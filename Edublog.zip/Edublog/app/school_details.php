<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class school_details extends Model
{
	protected $table = "school_details";

    protected $fillable = [
    			'user_id',
    			'school_name',
    			'school_address',
    			'school_state',
    			'school_city',
    			'school_postal_code',
    			'school_phone1',
    			'school_phone2',
    			'school_email',
    			'school_logo',
    			'school_person_name',

    ];
}
