<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class add_division extends Model
{
    protected $fillable = [
    		'division_name',
    ];
}
