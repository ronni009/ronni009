<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


Route::get('/', function () {
    return view('auth.login');                        //login page
});

Route::auth();
Route::auth();
Route::group(['middleware'=>'auth'],function() {
	Route::get('/dashboard','LoginController@index'); //dashboard

	Route::resource('users','UserController');            //user
	Route::resource('roles','RoleController');           //role
	Route::resource('school','ManageSchoolController');  //school 
	Route::resource('standard','StandardController');    //standard
	Route::resource('division','DivisionController');    //division
	Route::post('adddiv',['uses'=>'DivisionController@divstore','as'=>'add.div']);  //add division
	Route::resource('subject','SubjectController');      //subject
	Route::resource('subtostd','SubjectToStandard');     //subject to standard
	Route::resource('teacher','TeacherController');      //teacher
	Route::resource('time','TimeTableController');       //timetable
	Route::resource('class','ClassTeacherController');   //class teacher
});

Route::get('/home', 'HomeController@index');
