<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\standard_master;
use App\division_master;
use App\teachers_detail;

class ClassTeacherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stdDiv = division_master::leftjoin('teachers_details','division_masters.teacher_id','=','teachers_details.unique_id')
                                    ->select('division_masters.*','teachers_details.name')->get();

        $teacherId = teachers_detail::lists('name','unique_id'); 
        return view('pages.class.index',compact('stdDiv','teacherId'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $stdDiv = division_master::leftjoin('teachers_details','division_masters.teacher_id','=','teachers_details.unique_id')
                                    ->select('division_masters.*','teachers_details.name')->get();

        $teacherId = teachers_detail::lists('name','unique_id'); 
        return view('pages.class.create',compact('stdDiv','teacherId'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        try {
            $teacherId = teachers_detail::lists('name','unique_id'); 
            $divEdit = division_master::leftjoin('teachers_details','division_masters.teacher_id','=','teachers_details.unique_id')
                                    ->select('division_masters.*','teachers_details.name')
                                    ->where('division_masters.id',$id)->first();

        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        
        return view('pages.class.edit',compact('divEdit','teacherId'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        try {
            // validation
            $this->validate($request,[
                'teacher_id' => 'required|unique:division_masters,teacher_id,'.$id,
                ]);
            // data store
            $update = $request->all();
            // data operate
            division_master::where('id',$id)->update([
                'teacher_id' => $update['teacher_id'],
                ]);
        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('class.index')->with('updated','data updated successfully!');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
