<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\standard_master;

class StandardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $standardDetail = standard_master::all();
        return view('pages.standard.index',compact('standardDetail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
    try {
        // validation
        $this->validate($request,[
            'standard_name' => 'required|unique:standard_masters,standard_name',
            ]);
        // data storing 
        $input = $request->all();
        // data operate
        standard_master::create([
            'standard_name' => $input['standard_name'],
            ]);

        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
     return redirect()->route('standard.index')->with('success','Standard Added successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $standardEdit = standard_master::where('id',$id)->first();
        return view('pages.standard.edit',compact('standardEdit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        try {
            // validation
            $this->validate($request,[          
                'standard_name' => 'required|unique:standard_masters,standard_name,'.$id,
                ]);
            // data store
            $update = $request->all();
            // data operate
            standard_master::where('id',$id)->update([
                'standard_name' => $update['standard_name'],
                ]);

        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('standard.index')->with('updated','data successfully updated!');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
