<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\timetable_master;

class TimeTableController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $timeDetail = timetable_master::all();
        return view('pages.timetable.index',compact('timeDetail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
    try {
        // validation
        $this->validate($request,[
            'from' => 'required',
            'to' => 'required',
            ]);
        // data store
        $input = $request->all();
        // condition
        $chk = timetable_master::where('from',$input['from'])->where('to',$input['to'])->get();
        if($chk->count()) {
            return redirect()->route('time.index')->with('exists','the entered time already exists');
        } else {
        // data operate
        timetable_master::create([
            'from' => $input['from'],
            'to' => $input['to'],
            ]);
          }
    } catch(Exception $ex){
        
        echo 'message : ' .$ex->getMessage();
    }
        return redirect()->route('time.index')->with('success','added successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        try {
            $timeEdit = timetable_master::where('id',$id)->first();
            return view('pages.timetable.edit',compact('timeEdit'));

        } catch(Exception $ex){
            
            echo 'message : ' .$ex->getMessage();
        }
        
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        try {
            // validation
            /*$this->validate($request,[
                'from' => 'required|unique:timetable_masters,from,'.$id,
                'to' => 'required',
                ]);*/
            // data store
            $update = $request->all();
            // condition
            $chk = timetable_master::where('from',$update['from'])->where('to',$update['to'])->get();

            if ($chk->count()) {
                return redirect()->route('time.index')->with('exists','both your credentials already exists!');
            } else {
            // data operate
            timetable_master::where('id',$id)->update([
                'from' => $update['from'],
                'to' => $update['to'],
                ]);
            }
        } catch(Exception $ex){
            
            echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('time.index')->with('updated','updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        timetable_master::where('id',$id)->delete();
        return redirect()->route('time.index')->with('deleted','deleted successfully!');
    }
}
