<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Entrust;
use App\User;
use App\Role;
use App\DeviceDetails;
use App\teachers_detail;
use DB;
use Auth;   
use Hash;

class TeacherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $teacherDetail = teachers_detail::all();            
        return view('pages.teacher.index',compact('teacherDetail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $today = date('Ymd');
        $unique_id = uniqid($today.'_');
        $roles = Role::where('id','=',3)->lists('display_name','id');
        return view('pages.teacher.create',compact('roles','unique_id'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        try {
             $this->validate($request, [
            'name' => 'required|alpha',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|same:confirm-password',
            'roles' => 'required',
           // 'resume' => 'required',
            'teacher_birthdate' => 'required',
        ]);

       $input = $request->except('teacher_photo'); 

       $image = $request->teacher_photo;

       $input = $request->except('resume');

       $resume = $request->resume;

       if ($image) {
        $imageName = $image->getClientOriginalName();
        $image->move('images',$imageName);
        $input['teacher_photo'] = $imageName;
       }

       if ($resume) {
            $docName = $resume->getClientOriginalName();
            $resume->move('download',$docName);
            $input['resume'] = $docName;
           }

        $input['name']=ucfirst($input['name']);
        $input['password'] = Hash::make($input['password']);

        $user = User::create([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' => $input['password'],
            'unique_id' => $input['unique_id'],
            ]);
       // foreach ($request->input('roles') as $key => $value) {
           
            $user->roles()->attach($request->input('roles'));
        //}

            $userData = User::where('unique_id',$input['unique_id'])->first();
            
        if ($input['roles'] == 3) {

            teachers_detail::create([
            'name' => $userData->name,
            'user_id' => $userData->id,
            'email' => $userData->email,
            'teacher_birthdate' => $input['teacher_birthdate'],
            'unique_id' => $input['unique_id'],
            'gender' => $input['gender'],
            'marital_status' => $input['marital_status'],
            'teacher_address' => $input['teacher_address'],
            'teacher_phone' => $input['teacher_phone'],
            'roles' => $input['roles'],
            'teacher_exp' => $input['teacher_exp'],
            'teacher_education' => $input['teacher_education'],
            'teacher_notes' => $input['teacher_notes'],
            'editor1' => $input['editor1'],
            'designation' => $input['designation'],
            'teacher_photo' => $input['teacher_photo'],
           // 'resume' => $input['resume'],
                ]);

            return redirect()->route('teacher.index')->with('success','added successfully!');
        }

        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }

        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $today = date('Ymd');
        $unique_id = uniqid($today.'_');
        $roles = Role::where('id','=',3)->lists('display_name','id');
        $teacherEdit = teachers_detail::rightjoin('users','users.unique_id','=','teachers_details.unique_id')
                                        ->select('users.*','teachers_details.*')
                                        ->where('teachers_details.id','=',$id)->first();
        return view('pages.teacher.edit',compact('roles','unique_id','teacherEdit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
        try {
            $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:users,email,'.$id,
            'roles' => 'required'
        ]);

       /* return $input = $request->all();*/ 

        $input = $request->except('teacher_photo'); 

        $input = $request->except('resume');

        $resume = $request->resume;

       $image = $request->teacher_photo;

       if ($image) {
        $imageName = $image->getClientOriginalName();
        $image->move('images',$imageName);
        $input['teacher_photo'] = $imageName;
       } else {
        $input['teacher_photo'] = $input['files'];
       }


      /* $doc = @$input['resume'];*/

           if ($resume) {
            $docName = $resume->getClientOriginalName();
            $resume->move('download',$docName);
            $input['resume'] = $docName;
           } else {
           // $input['resume'] = $input['subresume'];
           } 
       
       
        if(!empty($input['password'])){ 
            $input['password'] = Hash::make($input['password']);
        }else{
            $input = array_except($input,array('password'));    
        }

        $user = User::where('unique_id','=',$input['unique_id'])->first();
        $userId = $user->id;
        $userData = User::where('id',$userId)->first();
        $userData->update([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' => $input['password'],
            'unique_id' => $input['unique_id'],
            ]);

      
        DB::table('role_user')->where('user_id',$userId)->delete();
 
        
       // foreach ($request->input('roles') as $key => $value) {
            //$user->attachRole($value);
           // $user->attach($value);
              $user->roles()->attach($request->input('roles'));
       // }
        if ($input['roles'] == 3) {

            teachers_detail::where('user_id',$id)->update([
            'name' => $userData->name,
            'email' => $userData->email,
            'teacher_birthdate' => $input['teacher_birthdate'],
            'unique_id' => $input['unique_id'],
            'gender' => $input['gender'],
            'marital_status' => $input['marital_status'],
            'teacher_address' => $input['teacher_address'],
            'teacher_phone' => $input['teacher_phone'],
            'roles' => $input['roles'],
            'teacher_exp' => $input['teacher_exp'],
            'teacher_education' => $input['teacher_education'],
            'teacher_notes' => $input['teacher_notes'],
            'editor1' => $input['editor1'],
            'designation' => $input['designation'],
            'teacher_photo' => $input['teacher_photo'],
           // 'resume' => $input['resume'],
                ]);
            return redirect()->route('teacher.index')->with('updated','data updated successfully!');
        }

        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
            
            
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
