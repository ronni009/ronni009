<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\subject_master;
use App\standard_master;
use App\subject_to_std;

class SubjectToStandard extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stdDetail = subject_to_std::all();
        return view('pages.subject.index2',compact('stdDetail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $standardDetail = standard_master::all()->lists('standard_name','standard_name');
        $subjectDetail = subject_master::all()->lists('subject_name','subject_name');
        $substd = subject_to_std::all();
        return view('pages.subject.create',compact('standardDetail','subjectDetail','substd'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            // validation
            $this->validate($request,[
                'standard_name' => 'required|unique:subject_to_stds,standard_name',
                ]);
            // data store
            $input = $request->all();
            // condition

            // data operate 
            subject_to_std::create($input);
                
        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('subtostd.index')->with('success','data added successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $standardDetail = standard_master::all()->lists('standard_name','standard_name');
        $subjectDetail = subject_master::all()->lists('subject_name','subject_name');
        $subEdit = subject_to_std::where('id',$id)->first(); 
        return view('pages.subject.edit2',compact('standardDetail','subjectDetail','subEdit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        try {
            // validation
            $this->validate($request,[
                'standard_name' => 'required|unique:subject_to_stds,standard_name,'.$id,
                ]);
            // data store
            $update = $request->all();
            // data operate
            subject_to_std::where('id',$id)->update([
                'standard_name' => $update['standard_name'],
                'sub1' => $update['sub1'],
                'sub2' => $update['sub2'],
                'sub3' => $update['sub3'],
                'sub4' => $update['sub4'],
                'sub5' => $update['sub5'],
                'sub6' => $update['sub6'],
                'sub7' => $update['sub7'],
                'sub8' => $update['sub8'],
                'sub9' => $update['sub9'],
                'sub10' => $update['sub10'],
                'sub11' => $update['sub11'],
                'sub12' => $update['sub12'],
                'sub13' => $update['sub13'],
                'sub14' => $update['sub14'],
                'sub15' => $update['sub15'],
                ]);
        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('subtostd.index')->with('updated','data updated successfully!');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
