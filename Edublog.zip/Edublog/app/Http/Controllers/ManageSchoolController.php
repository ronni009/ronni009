<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\school_details;
use Auth;

class ManageSchoolController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $schoolDetail = school_details::all();
        return view('pages.school.index',compact('schoolDetail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.school.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         try {

            $this->validate($request,[
                'school_name' => 'required',
                'school_address' => 'required',
                'school_state' => 'required',
                'school_city' => 'required',
                'school_postal_code' => 'required',
                'school_phone1' => 'required',
                'school_phone2' => 'required',
                'school_email' => 'required|unique:school_details,school_email',
                'school_logo' => 'required',
                'school_person_name' => 'required',

                ]);
                
            $input = $request->except('school_logo');
            $image = $request->school_logo;
            
            if($image) {
                $imageName = $image->getClientOriginalName();
                $image->move('images',$imageName);
                $input['school_logo'] = $imageName;
            } 

            school_details::create([
                'user_id' => Auth::user()->id,
                'school_name' => $input['school_name'],
                'school_address' => $input['school_address'],
                'school_state' => $input['school_state'],
                'school_city' => $input['school_city'],
                'school_postal_code' => $input['school_postal_code'],
                'school_phone1' => $input['school_phone1'],
                'school_phone2' => $input['school_phone2'],
                'school_email' => $input['school_email'],
                'school_logo' => $input['school_logo'],
                'school_person_name' => $input['school_person_name'],
                ]);


             } catch(Exception $ex){
                
                echo 'message : ' .$ex->getMessage();
             }
        return redirect()->route('school.index')->with('success','Added Successfully');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $schoolEdit = school_details::where('id',$id)->first();
        return view('pages.school.edit',compact('schoolEdit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
     try {

        $this->validate($request,[
                'school_name' => 'required',
                'school_address' => 'required',
                'school_state' => 'required',
                'school_city' => 'required',
                'school_postal_code' => 'required',
                'school_phone1' => 'required|digits:10',
                'school_phone2' => 'required|digits:10',
                'school_email' => 'required|unique:school_details,school_email,'.$id,
                
                'school_person_name' => 'required',

                ]);

         $update = $request->except('school_logo');
         $image = $request->school_logo;

         if($image) {
            $imageName = $image->getClientOriginalName();
            $image->move('images',$imageName);
            $update['school_logo'] = $imageName;
         } else {
            $update['school_logo'] = $update['files'];
         }

         school_details::where('id',$id)->update([
                'user_id' => $update['user_id'],
                'school_name' => $update['school_name'],
                'school_address' => $update['school_address'],
                'school_state' => $update['school_state'],
                'school_city' => $update['school_city'],
                'school_postal_code' => $update['school_postal_code'],
                'school_phone1' => $update['school_phone1'],
                'school_phone2' => $update['school_phone2'],
                'school_email' => $update['school_email'],
                'school_logo' => $update['school_logo'],
                'school_person_name' => $update['school_person_name'],
            ]);
        } catch(Exception $ex){
            
            echo 'message : ' .$ex->getMessage();
        }    
        return redirect()->route('school.index')->with('updated','updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
