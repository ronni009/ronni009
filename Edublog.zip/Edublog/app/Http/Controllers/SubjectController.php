<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\subject_master;
use App\standard_master;
use App\subject_to_std;

class SubjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subjectDetail = subject_master::all();
        return view('pages.subject.index',compact('subjectDetail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        try {
        // validation
          $this->validate($request,[
           // 'subject_name' => 'required|unique:subject_masters,subject_name',
            ]);
        // data store
          $input = $request->all();
        // data operate
          subject_master::create([
            'subject_name' => ucfirst($input['subject_name']),
            ]);
        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('subject.index')->with('success','subject added successfully!');        
    }

    public function store2(Request $request)
    {
        
        try {
            // validation
            $this->validate($request,[
                'standard_name' => 'required|unique:subject_to_stds,standard_name',
                ]);
            // data store
            $input = $request->all();
            // condition

            // data operate 
            subject_to_std::create($input);
                
        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('subject.create')->with('success','data added successfully!');
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $subjectEdit = subject_master::where('id',$id)->first();
        return view('pages.subject.edit',compact('subjectEdit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        try {
            // validation
            $this->validate($request,[
                'subject_name' => 'required|unique:subject_masters,subject_name,'.$id,
                ]);
            // data store
            $update = $request->all();
            // data operate
            subject_master::where('id',$id)->update([
                'subject_name' => $update['subject_name'],
                ]);

        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('subject.index')->with('updated','data updated successfully!');        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
