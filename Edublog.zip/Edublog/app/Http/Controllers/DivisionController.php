<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\division_master;
use App\standard_master;
use App\add_division;

class DivisionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $divisionDetail = division_master::all();
        $standardDetail = standard_master::all()->lists('standard_name','id');
        $divAdd = add_division::all()->lists('division_name','division_name');
        return view('pages.division.index',compact('divAdd','standardDetail','divisionDetail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        try {
        // validation
        $this->validate($request,[
            //'standard_division' => 'required|unique:division_masters,standard_division',
            ]);

        // data store
        $input = $request->all();
        $standard_division = "";
        $standard_division .= $input['standard_name'];
        $standard_division .= $input['division_name'];

        // condition
        $chk = division_master::where('standard_division','=',$standard_division)->get();

        if ($chk->count()) {
            return redirect()->route('division.index')->with('exists','data already exists');
        } else {

        // data operate
        division_master::create([
            'standard_division' => $standard_division,
            ]);
        }
           
        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('division.index')->with('success','division added succesfully!');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $divAdd = add_division::all()->lists('division_name','division_name');
        $divisionEdit = division_master::where('id',$id)->first();
        $divisionName = explode(',',$divisionEdit->division_name);
        return view('pages.division.edit',compact('divisionEdit','divAdd','divisionName'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        try {
            // validation
            $this->validate($request,[
                'standard_division' => 'required|unique:division_masters,standard_division,'.$id,
                ]);
            // data store
            $update = $request->all();
    
            // data operate
            division_master::where('id',$id)->update([
                'standard_division' => $update['standard_division'],
                ]);
        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        return redirect()->route('division.index')->with('updated','data updated succesfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function divstore(Request $request)
    {

        try {
            // validation 
            $this->validate($request,[
                'division_name' => 'required|unique:add_divisions,division_name',
                ]);
            // data store
            $input = $request->all();
            // condition
           /* $chk = add_division::where('division_name',$input['division_name'])->get();
            if ($chk->count()) {
                $response['status'] == "UNSUCESS";
                return response()->json($response);
            }*/
            //data operate
            add_division::create([
                'division_name' => ucfirst($input['division_name']),
                ]);
        } catch(Exception $ex){

        echo 'message : ' .$ex->getMessage();
        }
        $response['status'] = "SUCCESS";
        return Response()->json($response);

    }
}
