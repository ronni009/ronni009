<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class division_master extends Model
{
	protected $table = "division_masters";

    protected $fillable =[
    	'standard_division',
    	'teacher_id',
    ];
}
