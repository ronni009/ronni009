<?php $__env->startSection('content'); ?>

<?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
  <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php if($message = Session::get('updated')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
   <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
    <section class="content-header">

          <h1>

            Add Teacher

            <small>Manage Teacher</small>

          </h1>

          <ol class="breadcrumb">

            <li><a href="#"><i class="fa fa-dashboard"></i> Teacher</a></li>

            <li class="active">Add Teacher</li>

          </ol>

        </section>



        <!-- Main content -->

        <section class="content">

            <div class="row">

              <div class="col-md-12">

                <a href="<?php echo e(route('teacher.index')); ?>" class="btn btn-primary pull-right">List</a>

                </div>

                <div class="col-md-12">
                  <?php echo Form::open(['route'=>'teacher.store','method'=>'post','enctype'=>'multipart/form-data']); ?>


                    <div class="box">

                        <div class="box-header">

                           

                        </div>

                        <div class="box-body">

                        

                            

                              <div class="box-body">

                             
                        



                        

                                <div class="form-group">

                                    <div class="row">

                                    <div class="col-md-12">

                                    <p style="border-bottom: 1px solid black;"><strong>Teacher Detail</strong> (Please Fill * all Required Field)</p>

                                    </div>

                                   <h4 class="box-title">General Information</h4>

                                      <div class="col-md-6">

                                      

                                        <label for="name">Teacher Name<span class="red">*</span></label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">

                                    </div>

                                    <div class ="col-md-6">
                                      <?php echo Form::label('unique_id','Unique Id'); ?>

                                      <?php echo Form::text('unique_id',@$unique_id,['class'=>'form-control','enabled'=>'enabled']); ?>

                                    </div>

                                    <div class="col-md-6">

                                        <label for="teacher_birthdate">Teacher Birthdate <span class="red">*</span></label>

                                        <input type="text" class="form-control" id="teacher_birthdate" name="teacher_birthdate" placeholder="Show Date" data-inputmask="'alias': 'yyyy/mm/dd'" data-mask value="">

                                    </div>

                                     <div class="col-md-6">

                                     <label>Gender :</label>

                                      <div class="radio">

                                        <label>

                                          <input type="radio" checked="" value="male" id="" name="gender" />

                                          Male

                                        </label>

                                        <label>

                                          <input type="radio" value="female" id="" name="gender" />

                                          Female

                                        </label>

                                      </div>

                                       

                                    </div>

                                    <div class="col-md-6">

                                     <label>Marital Status</label>

                                      <div class="radio">

                                        <label>

                                          <input type="radio" checked="" value="single" id="" name="marital_status" />

                                          Single

                                        </label>

                                        <label>

                                          <input type="radio" value="married" id="" name="marital_status" />

                                          Married

                                        </label>

                                      </div>

                                       

                                    </div>

                                 

                                     <div class="col-md-6">

                                        <label for="teacher_address">Teacher Address <span class="red">*</span></label>

                                       <textarea rows="3" id="teacher_address" name="teacher_address" class="form-control"> </textarea>

                                    </div>

                                    

                                     <div class="col-md-6">

                                        <label for="teacher_phone">Teacher Mobile  <span class="red">*</span></label>

                                        <input type="text" class="form-control" id="teacher_phone" name="teacher_phone" value=""/>

                                    </div>

                                     <div class="col-md-6">

                                        

                                         <label for="exampleInputPassword1">E-mail <span class="red">*</span></label>
                  <input type="email" class="form-control" name="email" id="email" placeholder="E-mail" > 
                                </div>
                                <div class = "col-md-6">
                                         <label for="password">Password<span class="red">*</span></label>
                  <input type="password" class="form-control" name="password" id="password" placeholder="Password" >
                                  </div>
                                  <div class = "col-md-6">
                  <label for="confirmpasw">Confirm Password<span class="red">*</span></label>
                  <input type="password" class="form-control" name="confirm-password" id="confirm-password" placeholder="Confirm Password" >
                                  </div>
                  <input type = "hidden" value = "<?php echo e(@$roles); ?>" name = "roles">
                      <div id="hid" class ="col-md-6">
                  <?php echo Form::label('role','Your Role'); ?><br>
                 <?php echo Form::select('roles', $roles, ['class' => 'form-control select2' , 'name' =>'role','disabled'=>'disabled']); ?>


                
                                    </div>

                                    

                                 

                                     <div class="col-md-6">

                                        <label for="teacher_photo">Teacher Photo </label>

                                        <input type="file" class="form-control" id="teacher_photo" name="teacher_photo" />

                                    </div>

                                

                                    

                                    

                                    </div>

                                </div>

                              

                              </div><!-- /.box-body -->

              

                        </div>

                    </div>

                     <div class="box">

                        <div class="box-header">

                           

                        </div>

                        <div class="box-body">

                           

                              <div class="box-body">

                        

                                 <div class="form-group">

                                    <div class="row">

                                   

                                   <h4 class="box-title">Education Information</h4>

                                    

                               

                                     <div class="col-md-6">

                                        <label for="teacher_exp">Teaching Experience  </label>

                                        <input type="text" class="form-control" id="teacher_exp" name="teacher_exp" placeholder="Ex. 1 year 6 month, 6 month, 4 year, ect" value=""/>

                                    </div>

                                    <div class="col-md-6">

                                        <label for="teacher_education">Teacher Education  <span class="red">*</span></label>

                                        <input type="text" class="form-control" id="teacher_education" name="teacher_education" placeholder="Ex. M.A., B.Ed, Phd, P.T.C, Etc" value=""/>

                                    </div>

                                  

                                    <div class="col-md-6">

                                        <label for="teacher_notes">Extra Notes </label>

                                       <textarea rows="2" id="teacher_notes" name="teacher_notes" placeholder="extra activity, extra archivement, award, etc" class="form-control"></textarea>

                                    </div>

                                      <div class="col-md-12">

                                      <label for="teacher_detail">Teacher Detail <span class="red">*</span> </label>

                                      <br /><label>Note <span class="red">*</span>: Teacher Standard, Teacher Subject, Teacher All Detail, Etc</label>

                                         <textarea id="editor1" name="editor1" rows="10" cols="80" >

                                          <?php if(isset($_REQUEST["editor1"])){echo $_REQUEST["editor1"]; } ?>  

                                        </textarea>

                                    </div>

                                    <div class ="col-md-6">
                                      <?php echo Form::label('designation','Teacher Designation'); ?><span class="red">*</span>
                                      <?php echo Form::text('designation',null,['class'=>'form-control','placeholder'=>'Enter here..']); ?>

                                    </div>
                                   
                                   <?php /*  <div class ="col-md-6">
                                       <?php echo Form::label('resume','Attach Resume'); ?><span class="red">*</span>
                                      <?php echo Form::file('resume',null,['class'=>'form-control']); ?>

                                    </div> */ ?>
                                    

                                    

                                    </div>

                                </div>

                              

                              </div><!-- /.box-body -->

            

                              <div class="box-footer">

                                <input type = "submit" value = "save data" class = "btn btn-primary">

                              </div>

                            <?php echo Form::close(); ?>


                        </div>

                    </div>

                </div>

               

                

            </div>

        </section><!-- /.content -->
<!-- ckeditor -->
<script src="<?php echo e(url('bower_components/AdminLTE/plugins/ckeditor/ckeditor.js')); ?>"></script>

<script>

      $(function () {

       

        CKEDITOR.replace('editor1');

        //bootstrap WYSIHTML5 - text editor

        $(".textarea").wysihtml5();

      });

    </script> 

    <script>
        $(document).ready(function(){
            $('#teacher_birthdate').datepicker();
        });
   </script>

<script type="text/javascript">
  $(document).ready(function(){
    $('#hid').hide();
  });
</script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>