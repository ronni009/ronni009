<!DOCTYPE html>
<html>

  <head>
  
  <?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
  </head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
    <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content-header">
      <h1>Dashboard</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('dashboard/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li><p bgcolor="blue">
      </ol>
    </section>
    <section class="content">
      <div class="row">
       <?php /*  <?php if(Auth::check()): ?>
          @role('school admin') */ ?>
          <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-maroon">
              <div class="inner">
                <h3>0</h3>
                <p>School Events</p>
              </div>
              <div class="icon">
                <i class="ion ion-calendar"></i>
              </div>
              <a href="" class="small-box-footer">Manage Events <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      
         <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-green">
              <div class="inner">
                <h3>0</h3>
                <p>Student Available</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="" class="small-box-footer">Add Student <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
         
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-purple">
              <div class="inner">
                <h3>0</h3>
                <p>Teacher Available</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="" class="small-box-footer">Add Teacher <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

       <?php /*  <?php if(Auth::check()): ?>
          @role('admin') */ ?>
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-teal">
              <div class="inner">
                <h3>0</h3>
                <p>Exam</p>
              </div>
              <div class="icon">
                <i class="ion ion-briefcase"></i>
              </div>
              <a href="" class="small-box-footer">Manage Exam <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
       <?php /*    @endrole
        <?php endif; ?> */ ?>
      

      <?php /* month wise orders and total bill inserted here */ ?>
     <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-yellow">
              <div class="inner">
                <h3>0</h3>
                <p>Upcomming Holidays</p>
              </div>
              <div class="icon">
                <i class="fa fa-newspaper-o"></i>
              </div>
              <a href="" class="small-box-footer">View Holidays <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-red">
              <div class="inner">
                <h3>0</h3>
                <p>Todays Event</p>
              </div>
              <div class="icon">
                <i class="fa fa-calendar"></i>
              </div>
              <a href="" class="small-box-footer">View Todays Event <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
       <?php /*  @endrole
          <?php endif; ?>

       <?php if(Auth::check()): ?>
        @role('admin')    */ ?>
          <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-red">
              <div class="inner">
                <h3><?php /* <?php echo e(count($UserCount)); ?> */ ?></h3>
                <p>User Registration</p>
              </div>
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>
              <a href="<?php echo e(route('users.index')); ?>" class="small-box-footer">View users <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
       <?php /*  @endrole
          <?php endif; ?> */ ?>

    </section>
    </div>
    <!-- /.content -->
  </div>
  

  
</div>
<!-- ./wrapper -->

 <?php echo $__env->make('includes.admin.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
