 

<?php $__env->startSection('content'); ?>
        <?php /* messages */ ?>
    <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
        </div>
    <?php endif; ?> 
  <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php if($message = Session::get('exists')): ?>
    <div class="alert alert-danger">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php if($message = Session::get('updated')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
   <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php /* box begins */ ?>
   <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            List Class Teacher
            <small>List Class Teacher</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo e(route('class.create')); ?>"><i class="fa fa-dashboard"></i>Add Class Teacher</a></li>
            <li class="active">List Class Teacher</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
               
                <div class="col-md-12">
                
                
                    <div class="col-md-12">
                    <div class="box">
                <div class="box-header">
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Standard Division</th>
                        <th>Select Teacher</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                <?php $__empty_1 = true; foreach($stdDiv as $stdDivs): $__empty_1 = false; ?>
                    <tr>
                        
                        <td><?php echo e($stdDivs->id); ?></td>
                        <td><?php echo e($stdDivs->standard_division); ?></td>

                         

                        <td><?php echo Form::select('teacher_id',@$teacherId,@$stdDivs->teacher_id,['class'=>'form-control','placeholder'=> 'select here..','id'=>'sel_class','disabled'=>'disabled']); ?></td>
                        <td>
                          <a href="<?php echo e(route('class.edit',$stdDivs->id)); ?>" class="btn btn-success"><i class="fa fa-edit"></i></a>
                        </td>
                        
                    </tr>
                    <?php endforeach; if ($__empty_1): ?>
                    <tr class="odd gradeX">
                    <td colspan=3 class="text-center">No Records Found</td>
                    </tr>  
                  <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
                    </div>
                </div>
               
                
            </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#from').timepicker();
        });
   </script>

   <script>
        $(document).ready(function(){
            $('#to').timepicker();
        });
   </script>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
              <script type="text/javascript">
              $(document).ready(function(){
                $('#btn_class').on('click',function(){
                  var teacherID = $('#sel_class').val();
                  var Id = $('#classID').val(); 
                  $.ajax({
                    type:'PATCH',
                    contentType:'application/x-www-form-urlencoded',
                    url:'',
                    data:{teacherID:teacherID},
                    dataType:'JSON',
                    success: function(response) {
                      if (response.status=="SUCCESS") {
                        console.log(response);
                       window.location.href="<?php echo e(route('division.index')); ?>";
                      }
                      /*if (response.status=="UNSUCESS") {
                        $('#div_hide').show();
                        window.location.href="<?php echo e(route('division.index')); ?>";
                      }*/
                    }

                  }); 
                  return false;                 
                }); 
              });
              </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>