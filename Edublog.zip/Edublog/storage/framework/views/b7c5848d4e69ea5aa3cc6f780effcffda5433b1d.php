<?php $__env->startSection('content'); ?>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <p><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Add Standard</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

  <?php echo Form::open(['route'=>'subtostd.store','method'=>'POST']); ?>

       <?php echo csrf_field(); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
               <?php /*  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> */ ?>
              <?php echo Form::label('standard_name','Select standard'); ?>

              <?php echo Form::select('standard_name',$standardDetail,null,['class'=>'form-control','id'=>'standard_name','placeholder'=>'Select here..','required'=>'required']); ?>

            </div>

              <!-- /.form-group -->
               
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>

              <!-- /.form-group -->
            </div>

            <div class = "col-md-3">
              <div class = "form-group">
                  <?php echo Form::label('subject_id','Select Subject'); ?>

          <?php echo Form::select('sub1',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub2',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub3',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub4',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub5',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <button id = "add1" class = "btn btn-primary">Add More</button>

              </div>

            </div>


            <div id = "show1" class = "col-md-3">
              <div class = "form-group">
                  <?php echo Form::label('subject_id','Select Subject'); ?>

          <?php echo Form::select('sub6',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub7',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub8',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub9',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub10',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>


          <button id = "add2" class = "btn btn-primary">Add More</button>
              </div>

            </div>

            <div id = "show2" class = "col-md-3">
              <div class = "form-group">
                  <?php echo Form::label('subject_id','Select Subject'); ?>

          <?php echo Form::select('sub11',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub12',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub13',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub14',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php echo Form::select('sub15',$subjectDetail,null,['class'=>'form-control','id'=>'standard_id','placeholder'=>'Select here..']); ?><br>

          <?php /* <button class = "btn btn-primary">Add More</button> */ ?>
              </div>

            </div>

        </div>
    </div>
</div>



</section>

<script>
$(document).ready(
    function(){
            $("#show1").hide();
    });
</script>

<script>
$(document).ready(
    function(){
            $("#show2").hide();
    });
</script>

<script>
$(document).ready(
    function(){
        $("#add1").click(function () {
            $("#show1").show("slow");
        });

    });
</script>

<script>
$(document).ready(
    function(){
        $("#add2").click(function () {
            $("#show2").show("slow");
        });

    });
</script>

  <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>