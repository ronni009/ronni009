 

<?php $__env->startSection('content'); ?>
        <?php /* messages */ ?>
    <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
  <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php if($message = Session::get('exists')): ?>
    <div class="alert alert-danger">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php if($message = Session::get('updated')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
   <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php /* box begins */ ?>
   <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Division
            <small>Manage Division</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Division</a></li>
            <li class="active">Manage Division</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
               
                <div class="col-md-12">
                
                <div class="col-md-4">
                    <div class="box">
                        <div class="box-header">
                           <p><strong>Add Division (Ex. A,B,C,D,E,F etc)</strong></p>
                        </div>
                        <div class="box-body">
                        
                            
                              <div class="box-body">
                              
                                <div class="form-group">
                                    <div class="row">
                                   
                                      <div class="col-md-12">
                                        <div class ="form-group">
                                        <input type="text" class="form-control" id="div_txt" name="division_name" placeholder="Ex. A, B, C, D, etc" /><br>

                                        <button id="div_btn" class="btn btn-primary">Add Division</button><br>

                                       <?php /*  <div id="div_hide" style="color:red">data already exists*</div> */ ?>
                                      </div>

                          <?php echo Form::open(['route'=>'division.store','method'=>'POST']); ?>

                                <?php echo csrf_field(); ?>


                                        <?php echo Form::label('standard_name','Select Standard'); ?><span style = "color:red">*</span></label>
                                        <?php echo Form::select('standard_name',$standardDetail,null,['class'=>'form-control','placeholder'=>'Select here..','required'=>'required']); ?>


                                        <label for="division_name">Division Name <span style = "color:red">*</span></label>
                                        <?php echo Form::select('division_name',$divAdd,null,['class'=>'form-control select2','id'=>'select2','placeholder'=>'select division','required','required']); ?>

                                    </div>
                                   
                                    
                                    </div>
                                </div>
                             
                              </div><!-- /.box-body -->
            
                              <div class="box-footer">
                                <input type ="submit" value = "submit" class = "btn btn-primary">
                              </div>
                           <?php echo Form::close(); ?>

                        </div>
                    </div>
                    </div>
                    <div class="col-md-8">
                    <div class="box">
                <div class="box-header">
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Standard Division</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                <?php $__empty_1 = true; foreach($divisionDetail as $divisionDetails): $__empty_1 = false; ?>
                    <tr>
                        
                        <td><?php echo e($divisionDetails->id); ?></td>
                        <td><?php echo e($divisionDetails->standard_division); ?></td>

                       
                        <td>
                            <a href="<?php echo e(route('division.edit',$divisionDetails->id)); ?>" class="btn btn-success"><i class="fa fa-edit"></i></a>
                          <?php /*   <a href="" onclick="return confirm('are you sure to delete?')" class="btn btn-danger"><i class="fa fa-remove"></i></a> */ ?>
                        </td>
                    </tr>
                    <?php endforeach; if ($__empty_1): ?>
                    <tr class="odd gradeX">
                    <td colspan=4 class="text-center">No Records Found</td>
                    </tr>  
                  <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
                    </div>
                </div>
               
                
            </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
              <script type="text/javascript">
              $(document).ready(function(){
                $('#div_hide').hide();
                $('#div_btn').on('click',function(){
                  var division_name = $('#div_txt').val();
                
            
                  $.ajax({
                    type:'POST',
                    contentType:'application/x-www-form-urlencoded',
                    url:'<?php echo e(route("add.div")); ?>',
                    data:{division_name:division_name},
                    dataType:'JSON',
                    success: function(response) {
                      if (response.status=="SUCCESS") {
                       window.location.href="<?php echo e(route('division.index')); ?>";
                      }
                      /*if (response.status=="UNSUCESS") {
                        $('#div_hide').show();
                        window.location.href="<?php echo e(route('division.index')); ?>";
                      }*/
                    }

                  }); 
                  return false;                 
                }); 
              });
              </script>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>