 

<?php $__env->startSection('content'); ?>
        <?php /* messages */ ?>
    <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
  <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php if($message = Session::get('updated')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
   <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php /* box begins */ ?>
   <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Teacher
            <small>Manage Teacher</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Teacher</a></li>
            <li class="active">Manage Teacher</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">

               <div class="col-md-12">

                <a href="<?php echo e(route('teacher.create')); ?>" class="btn btn-primary pull-right">Add Teacher</a>

                </div>
               
                <div class="col-md-12">
                
                
                    <div class="col-md-12">
                    <div class="box">
                <div class="box-header">
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Teacher Name</th>
                        <th>Teacher Email</th>
                        <th>Teacher Phone</th>
                        <th>Teacher Birthdate</th>
                         <th>Gender</th>
                         <th>Marital Status</th>
                         <th>Teacher Address</th>
                        <th>Teacher Education</th>
                        <th>Teacher Experience</th>
                        <th>Teacher Notes</th>
                        <th>Designation</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                <?php $__empty_1 = true; foreach($teacherDetail as $teacherDetails): $__empty_1 = false; ?>
                    <tr>
                        
                        <td><?php echo e($teacherDetails->id); ?></td>
                        <td><?php echo e($teacherDetails->name); ?></td>
                        <td><?php echo e($teacherDetails->email); ?></td>
                        <td><?php echo e($teacherDetails->teacher_phone); ?></td>
                        <td><?php echo e($teacherDetails->teacher_birthdate); ?></td>
                        <td><?php echo e($teacherDetails->gender); ?></td>
                        <td><?php echo e($teacherDetails->marital_status); ?></td>
                        <td><?php echo e($teacherDetails->teacher_address); ?></td>
                        <td><?php echo e($teacherDetails->teacher_education); ?></td>
                        <td><?php echo e($teacherDetails->teacher_exp); ?></td>
                        <td><?php echo e($teacherDetails->teacher_notes); ?></td>
                        <td><?php echo e($teacherDetails->designation); ?></td>
                        
                        <td>
                          <?php /*  <a title="View Details" data-toggle="tooltip"  class="badge bg-blue" href="<?php echo e(route('teacher.show',$teacherDetails->id)); ?>" ><i class="fa fa-eye"></i></a> */ ?>
                            <a href="<?php echo e(route('teacher.edit',$teacherDetails->id)); ?>" class="btn btn-success"><i class="fa fa-edit"></i></a>
                           

                        </td>
                    </tr>
                    <?php endforeach; if ($__empty_1): ?>
                    <tr class="odd gradeX">
                    <td colspan=3 class="text-center">No Records Found</td>
                    </tr>  
                  <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
                    </div>
                </div>
               
                
            </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>