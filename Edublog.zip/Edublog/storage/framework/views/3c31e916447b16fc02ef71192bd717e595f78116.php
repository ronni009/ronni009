<?php $__env->startSection('content'); ?>
    <section class="content">

<style type="text/css">
img.zoom {
    width: 60px;
    height: 60px;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    -ms-transition: all .2s ease-in-out;
}
 
.transition {
    -webkit-transform: scale(2.8); 
    -moz-transform: scale(2.8);
    -o-transform: scale(2.8);
    transform: scale(2.8);
}

</style>

      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">School details</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

	<?php echo Form::open(['route'=>['school.update',$schoolEdit->id],'method'=>'PATCH' , 'enctype'=>'multipart/form-data']); ?>

       <?php echo method_field('PUT'); ?>

    <div class="box-body">
          <div class="row">

            <div class="col-md-6">
              <div class="form-group">
               <?php /*  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> */ ?>
              <?php echo Form::label('school_name','School Name'); ?><span style = "color:red">*</span>
              <?php echo Form::text('school_name',$schoolEdit->school_name,['class'=>'form-control','id'=>'school_name','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

            <div class = "form-group">
              <?php echo Form::label('school_address','School Address'); ?><span style = "color:red">*</span>
             <?php echo Form::text('school_address',$schoolEdit->school_address,['class'=>'form-control','id'=>'school_address','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

            <div class="form-group">
               <?php /*  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> */ ?>
              <?php echo Form::label('school_state','State Name'); ?><span style = "color:red">*</span>
              <?php echo Form::text('school_state',$schoolEdit->school_state,['class'=>'form-control','id'=>'school_state','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

            <div class="form-group">
               
              <?php echo Form::label('school_phone1','School Phone1'); ?><span style = "color:red">*</span>
              <?php echo Form::text('school_phone1',$schoolEdit->school_phone1,['class'=>'form-control','id'=>'school_phone1','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

            <div class="form-group">
               
              <?php echo Form::label('school_email','School Email'); ?><span style = "color:red">*</span>
              <?php echo Form::text('school_email',$schoolEdit->school_email,['class'=>'form-control','id'=>'school_email','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

            <div class="form-group">
               
              <?php echo Form::label('school_logo','School Logo'); ?><span style = "color:red">*</span>
              <input type = "hidden" name ="files" value ="<?php echo e($schoolEdit->school_logo); ?>">
              <input type = "hidden" name="user_id" value = "<?php echo e($schoolEdit->user_id); ?>">
              <?php echo Form::file('school_logo',null,['class'=>'form-control','id'=>'school_logo','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

              <!-- /.form-group -->
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
              
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Add School</button>
               </div>

               </div>  <!-- /.col-md-6 -->

            <div class="col-md-6">
              <div class="form-group">
              <?php echo Form::label('school_person_name','School Person Name'); ?><span style = "color:red">*</span>
              <?php echo Form::text('school_person_name',$schoolEdit->school_person_name,['class'=>'form-control','id'=>'school_person_name','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

            <div class="form-group">
              <?php echo Form::label('school_city','City Name'); ?><span style = "color:red">*</span>
              <?php echo Form::text('school_city',$schoolEdit->school_city,['class'=>'form-control','id'=>'school_city','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

            <div class="form-group">
              <?php echo Form::label('school_postal_code','Pin Code'); ?><span style = "color:red">*</span>
              <?php echo Form::text('school_postal_code',$schoolEdit->school_postal_code,['class'=>'form-control','id'=>'school_postal_code','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

            <div class="form-group">
              <?php echo Form::label('school_phone2','School Phone2'); ?><span style = "color:red">*</span>
              <?php echo Form::text('school_phone2',$schoolEdit->school_phone2,['class'=>'form-control','id'=>'school_phone2','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>

            <div class="form-group">
              <?php echo Form::label('school_phone2','Your School logo'); ?><br>
         
              <img class = "zoom" src="<?php echo e(url('images',@$schoolEdit->school_logo)); ?>"/> 
            </div>
              
              </div>


               

              <!-- /.form-group -->
           
        </div> <!-- /.row -->
    </div>
</div>
</section>

	<?php echo Form::close(); ?>



   <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/3.0.8/jquery.elevatezoom.js" type="text/javascript"></script>
<script>

   $(document).ready(function(){
    $('.zoom').hover(function() {
        $(this).addClass('transition');
    }, function() {
        $(this).removeClass('transition');
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>