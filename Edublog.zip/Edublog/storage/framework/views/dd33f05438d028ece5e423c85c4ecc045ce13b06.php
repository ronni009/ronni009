 

<?php $__env->startSection('content'); ?>
        <?php /* messages */ ?>
    <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
  <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php if($message = Session::get('updated')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
   <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php /* box begins */ ?>
   <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Standard
            <small>Manage Standard</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Standard</a></li>
            <li class="active">Manage Standard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
               
                <div class="col-md-12">
                
                <div class="col-md-4">
                    <div class="box">
                        <div class="box-header">
                           <p><strong>Add Standard (Ex. 1, 2, 8-A, 11-Arts H.K.G, L.K.G, etc)</strong></p>
                        </div>
                        <div class="box-body">
                        
                            <?php echo Form::open(['route'=>'standard.store','method'=>'POST']); ?>

                                <?php echo csrf_field(); ?>

                              <div class="box-body">
                              
                                <div class="form-group">
                                    <div class="row">
                                   
                                      <div class="col-md-12">
                                        <label for="standard_name">Standard Name <span style = "color:red">*</span></label>
                                        <input type="text" class="form-control" name="standard_name" placeholder="Ex. 1, 2, L.K.G, etc" />
                                    </div>
                                   
                                    
                                    </div>
                                </div>
                             
                              </div><!-- /.box-body -->
            
                              <div class="box-footer">
                                <input type ="submit" value = "submit" class = "btn btn-primary">
                              </div>
                           <?php echo Form::close(); ?>

                        </div>
                    </div>
                    </div>
                    <div class="col-md-8">
                    <div class="box">
                <div class="box-header">
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Standard Name</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                <?php $__empty_1 = true; foreach($standardDetail as $standardDetails): $__empty_1 = false; ?>
                    <tr>
                        
                        <td><?php echo e($standardDetails->id); ?></td>
                        <td><?php echo e($standardDetails->standard_name); ?></td>
                        
                        <td>
                            <a href="<?php echo e(route('standard.edit',$standardDetails->id)); ?>" class="btn btn-success"><i class="fa fa-edit"></i></a>
                           <?php /*  <a href="" onclick="return confirm('are you sure to delete?')" class="btn btn-danger"><i class="fa fa-remove"></i></a> */ ?>
                        </td>
                    </tr>
                    <?php endforeach; if ($__empty_1): ?>
                    <tr class="odd gradeX">
                    <td colspan=3 class="text-center">No Records Found</td>
                    </tr>  
                  <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
                    </div>
                </div>
               
                
            </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>