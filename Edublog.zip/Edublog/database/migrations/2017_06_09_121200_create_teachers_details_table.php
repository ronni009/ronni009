<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTeachersDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('teachers_details', function (Blueprint $table) {
            $table->increments('id');
            $table->string('teacher_birthdate');
            $table->string('gender');
            $table->string('marital_status');
            $table->string('teacher_address');
            $table->string('teacher_phone');
            $table->string('roles');
            $table->string('teacher_exp');
            $table->string('teacher_education');
            $table->string('teacher_notes');
            $table->string('editor1');
            $table->string('designation');
            $table->string('teacher_photo');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('teachers_details');
    }
}
