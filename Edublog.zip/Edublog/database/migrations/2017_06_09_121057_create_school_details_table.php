<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSchoolDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('school_details', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id');
            $table->string('school_name');
            $table->string('school_address');
            $table->string('school_state');
            $table->string('school_city');
            $table->integer('school_postal_code');
            $table->integer('school_phone1');
            $table->integer('school_phone2');
            $table->string('school_email');
            $table->string('school_logo');
            $table->string('school_person_name');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('school_details');
    }
}
