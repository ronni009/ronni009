<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSubjectToStdsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subject_to_stds', function (Blueprint $table) {
            $table->increments('id');
            $table->string('standard_name');
            $table->string('sub1');
            $table->string('sub2');
            $table->string('sub3');
            $table->string('sub4');
            $table->string('sub5');
            $table->string('sub6');
            $table->string('sub7');
            $table->string('sub8');
            $table->string('sub9');
            $table->string('sub10');
            $table->string('sub11');
            $table->string('sub12');
            $table->string('sub13');
            $table->string('sub14');
            $table->string('sub15');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('subject_to_stds');
    }
}
